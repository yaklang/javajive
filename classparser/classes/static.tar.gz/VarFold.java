package org.benf.cfr.reader;

import java.util.List;

public class VarFold {
	void common() {
		int var1 = 1;
		System.out.println(var1);
	}
	void commonNegative() {
		int var1 = 1;
		int var2 = var1;
		System.out.println(var2);
		int var3 = var1;
	}
	void scope() {
		if ((1) > (1)){
			int var1 = 1;
			var1 = 3;
			System.out.println(var1);
		}
		int var1 = 2;
		int var2 = 1;
		System.out.println(var1);
		System.out.println(var2);
		int var3 = 2;
		System.out.println(1);
		System.out.println(var3);
	}
	void newExpression() {
		String var1 = new String("");
	}
	void typeCase() {
		Integer var1 = Integer.valueOf(1);
		Object var2 = (var1 instanceof Object) ? (((List)(((java.lang.Object)(var1))))) : (var1.getClass());
	}
}