package org.benf.cfr.reader;

public class VarFold$Test extends VarFold {
	// Fields
	final VarFold this$0;

	public VarFold$Test(VarFold var1) {
		super(new Integer(1).intValue());
		this.this$0 = var1;
	}
}